let arr=[45,88,47,14,23,96,36,87,55];
console.log("unsorted",arr);
arr.sort((a,b) => b-a);
console.log("Sorted",arr);