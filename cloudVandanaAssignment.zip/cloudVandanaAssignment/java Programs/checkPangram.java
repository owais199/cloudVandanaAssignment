import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class checkPangram {
    public static void main(String[] args) {
         Scanner sc= new Scanner(System.in);
        System.out.println("Enter sentence");
        String str=sc.nextLine();
        String sentence = str.toLowerCase();

        Set<Character> alphabetSet = new HashSet();

        for(int i= 'a'; i<='z'; i++){
            alphabetSet.add((char) i);

        }
        for(int i=0;i<sentence.length();i++){
            alphabetSet.remove(sentence.charAt(i));
        }
        if(alphabetSet.isEmpty()){
            System.out.println("given string is pangram");
        }else{
            System.out.println("given string is not pangram");
        }
    }
}
